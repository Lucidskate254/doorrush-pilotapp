
export type AgentStatus = "online" | "offline";

export type OrderStatus = "pending" | "assigned" | "in_transit" | "delivered" | "cancelled";

export interface Agent {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  phone_number: string;
  national_id: string;
  service_area: string;
  profile_picture_url: string | null;
  agent_code: string;
  status: AgentStatus;
  total_earnings: number;
  completed_deliveries: number;
  created_at: string;
}

export interface Order {
  id: string;
  customer_id: string;
  customer_name: string;
  customer_phone: string;
  pickup_location: string;
  delivery_location: string;
  delivery_notes?: string;
  status: OrderStatus;
  agent_id: string | null;
  amount: number;
  created_at: string;
  updated_at: string;
  verification_code: string;
}

export interface Message {
  id: string;
  order_id: string;
  sender_id: string;
  sender_type: "agent" | "customer";
  content: string;
  created_at: string;
}

export interface Activity {
  id: string;
  agent_id: string;
  activity_type: "login" | "status_change" | "order_accepted" | "order_completed";
  description: string;
  created_at: string;
}
