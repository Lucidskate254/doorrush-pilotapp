
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      agents: {
        Row: {
          id: string
          user_id: string
          full_name: string
          email: string
          phone_number: string
          national_id: string
          service_area: string
          profile_picture_url: string | null
          agent_code: string
          status: "online" | "offline"
          total_earnings: number
          completed_deliveries: number
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          full_name: string
          email: string
          phone_number: string
          national_id: string
          service_area: string
          profile_picture_url?: string | null
          agent_code: string
          status?: "online" | "offline"
          total_earnings?: number
          completed_deliveries?: number
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          full_name?: string
          email?: string
          phone_number?: string
          national_id?: string
          service_area?: string
          profile_picture_url?: string | null
          agent_code?: string
          status?: "online" | "offline"
          total_earnings?: number
          completed_deliveries?: number
          created_at?: string
        }
      }
      orders: {
        Row: {
          id: string
          customer_id: string
          customer_name: string
          customer_phone: string
          pickup_location: string
          delivery_location: string
          delivery_notes: string | null
          status: "pending" | "assigned" | "in_transit" | "delivered" | "cancelled"
          agent_id: string | null
          amount: number
          created_at: string
          updated_at: string
          verification_code: string
        }
        Insert: {
          id?: string
          customer_id: string
          customer_name: string
          customer_phone: string
          pickup_location: string
          delivery_location: string
          delivery_notes?: string | null
          status?: "pending" | "assigned" | "in_transit" | "delivered" | "cancelled"
          agent_id?: string | null
          amount: number
          created_at?: string
          updated_at?: string
          verification_code: string
        }
        Update: {
          id?: string
          customer_id?: string
          customer_name?: string
          customer_phone?: string
          pickup_location?: string
          delivery_location?: string
          delivery_notes?: string | null
          status?: "pending" | "assigned" | "in_transit" | "delivered" | "cancelled"
          agent_id?: string | null
          amount?: number
          created_at?: string
          updated_at?: string
          verification_code?: string
        }
      }
      messages: {
        Row: {
          id: string
          order_id: string
          sender_id: string
          sender_type: "agent" | "customer"
          content: string
          created_at: string
        }
        Insert: {
          id?: string
          order_id: string
          sender_id: string
          sender_type: "agent" | "customer"
          content: string
          created_at?: string
        }
        Update: {
          id?: string
          order_id?: string
          sender_id?: string
          sender_type?: "agent" | "customer"
          content?: string
          created_at?: string
        }
      }
      activities: {
        Row: {
          id: string
          agent_id: string
          activity_type: "login" | "status_change" | "order_accepted" | "order_completed"
          description: string
          created_at: string
        }
        Insert: {
          id?: string
          agent_id: string
          activity_type: "login" | "status_change" | "order_accepted" | "order_completed"
          description: string
          created_at?: string
        }
        Update: {
          id?: string
          agent_id?: string
          activity_type?: "login" | "status_change" | "order_accepted" | "order_completed"
          description?: string
          created_at?: string
        }
      }
    }
  }
}
