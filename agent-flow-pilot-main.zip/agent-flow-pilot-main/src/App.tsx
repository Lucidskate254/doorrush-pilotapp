
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import AuthGuard from "@/components/AuthGuard";
import { ThemeProvider } from "next-themes";

// Pages
import LandingPage from "./pages/LandingPage";
import SignupPage from "./pages/SignupPage";
import SigninPage from "./pages/SigninPage";
import AgentRegistrationPage from "./pages/AgentRegistrationPage";
import DashboardPage from "./pages/DashboardPage";
import AvailableOrdersPage from "./pages/AvailableOrdersPage";
import ActiveOrdersPage from "./pages/ActiveOrdersPage";
import OrderDetailPage from "./pages/OrderDetailPage";
import CompletedOrdersPage from "./pages/CompletedOrdersPage";
import SettingsPage from "./pages/SettingsPage";
import AnalyticsPage from "./pages/AnalyticsPage";
import NotFoundPage from "./pages/NotFoundPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            {/* Public routes */}
            <Route 
              path="/" 
              element={
                <AuthGuard requireAuth={false} redirect="/dashboard">
                  <LandingPage />
                </AuthGuard>
              } 
            />
            <Route 
              path="/signup" 
              element={
                <AuthGuard requireAuth={false} redirect="/dashboard">
                  <SignupPage />
                </AuthGuard>
              } 
            />
            <Route 
              path="/signin" 
              element={
                <AuthGuard requireAuth={false} redirect="/dashboard">
                  <SigninPage />
                </AuthGuard>
              } 
            />
            
            {/* Protected routes */}
            <Route 
              path="/agent-registration" 
              element={
                <AuthGuard>
                  <AgentRegistrationPage />
                </AuthGuard>
              } 
            />
            <Route 
              path="/dashboard" 
              element={
                <AuthGuard>
                  <DashboardPage />
                </AuthGuard>
              } 
            />
            <Route 
              path="/orders/available" 
              element={
                <AuthGuard>
                  <AvailableOrdersPage />
                </AuthGuard>
              } 
            />
            <Route 
              path="/orders/active" 
              element={
                <AuthGuard>
                  <ActiveOrdersPage />
                </AuthGuard>
              } 
            />
            <Route 
              path="/orders/:id" 
              element={
                <AuthGuard>
                  <OrderDetailPage />
                </AuthGuard>
              } 
            />
            <Route 
              path="/orders/completed" 
              element={
                <AuthGuard>
                  <CompletedOrdersPage />
                </AuthGuard>
              } 
            />
            <Route 
              path="/settings" 
              element={
                <AuthGuard>
                  <SettingsPage />
                </AuthGuard>
              } 
            />
            <Route 
              path="/analytics" 
              element={
                <AuthGuard>
                  <AnalyticsPage />
                </AuthGuard>
              } 
            />
            
            {/* 404 route */}
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
