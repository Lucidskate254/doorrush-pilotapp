
import { createClient } from '@supabase/supabase-js';
import { Database } from '../types/supabase';

// These environment variables are automatically set by the Supabase integration
const supabaseUrl = 'https://ahxcqcohmdxlvhovrfup.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFoeGNxY29obWR4bHZob3ZyZnVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQzNjQwNDQsImV4cCI6MjA1OTk0MDA0NH0.pzc_XwZp2qRFd2DOXKgEcQoHHhAxFvQXH0oo1Eq3HjU';

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);
