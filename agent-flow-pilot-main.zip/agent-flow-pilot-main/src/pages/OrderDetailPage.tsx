
import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  MapPin, 
  Clock, 
  ChevronLeft, 
  Phone,
  MessageSquare,
  Package,
  Loader,
  Truck,
  QrCode,
  CheckCircle,
  Send
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Order, Agent, Message } from '@/types';
import { formatDistanceToNow } from 'date-fns';
import MainLayout from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from '@/components/ui/input';
import { Html5Qrcode } from 'html5-qrcode';

const OrderDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [agent, setAgent] = useState<Agent | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isScannerStarted, setIsScannerStarted] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isDeliverySuccessful, setIsDeliverySuccessful] = useState(false);
  
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  
  useEffect(() => {
    const fetchData = async () => {
      if (!user || !id) return;

      try {
        // Fetch agent data
        const { data: agentData, error: agentError } = await supabase
          .from('agents')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (agentError) throw agentError;
        setAgent(agentData);

        // Fetch order details
        const { data: orderData, error: orderError } = await supabase
          .from('orders')
          .select('*')
          .eq('id', id)
          .single();

        if (orderError) throw orderError;
        
        // Check if this agent is assigned to this order
        if (orderData.agent_id !== agentData.id) {
          toast({
            title: 'Access Denied',
            description: 'You are not assigned to this order',
            variant: 'destructive',
          });
          navigate('/orders/active');
          return;
        }
        
        setOrder(orderData);

        // Fetch messages
        const { data: messagesData, error: messagesError } = await supabase
          .from('messages')
          .select('*')
          .eq('order_id', id)
          .order('created_at', { ascending: true });

        if (messagesError) throw messagesError;
        setMessages(messagesData || []);

        // Set up real-time subscription for messages
        const messagesSubscription = supabase
          .channel('messages-channel')
          .on('postgres_changes', 
            { 
              event: 'INSERT', 
              schema: 'public', 
              table: 'messages',
              filter: `order_id=eq.${id}`
            }, 
            (payload) => {
              const newMessage = payload.new as Message;
              setMessages(prev => [...prev, newMessage]);
            })
          .subscribe();
        
        // Set up real-time subscription for order updates
        const orderSubscription = supabase
          .channel('order-channel')
          .on('postgres_changes', 
            { 
              event: 'UPDATE', 
              schema: 'public', 
              table: 'orders',
              filter: `id=eq.${id}`
            }, 
            (payload) => {
              setOrder(payload.new as Order);
            })
          .subscribe();
        
        // Clean up subscriptions on unmount
        return () => {
          messagesSubscription.unsubscribe();
          orderSubscription.unsubscribe();
        };

      } catch (error: any) {
        toast({
          title: 'Error',
          description: 'Failed to load order details: ' + error.message,
          variant: 'destructive',
        });
        navigate('/orders/active');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [user, id, navigate, toast]);

  // Scroll to bottom of messages when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Clean up scanner on unmount
  useEffect(() => {
    return () => {
      if (scannerRef.current && isScannerStarted) {
        scannerRef.current.stop();
      }
    };
  }, [isScannerStarted]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !agent || !order) return;

    try {
      await supabase
        .from('messages')
        .insert({
          order_id: order.id,
          sender_id: agent.id,
          sender_type: 'agent',
          content: newMessage,
        });
      
      setNewMessage('');
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to send message: ' + error.message,
        variant: 'destructive',
      });
    }
  };

  const updateOrderStatus = async (status: 'in_transit' | 'delivered') => {
    if (!order || !agent) return;
    
    setIsUpdating(true);
    
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status })
        .eq('id', order.id);
      
      if (error) throw error;
      
      // Create activity record
      await supabase
        .from('activities')
        .insert({
          agent_id: agent.id,
          activity_type: status === 'delivered' ? 'order_completed' : 'status_change',
          description: `Order #${order.id.substring(0, 8)} marked as ${status}`,
        });
      
      // If order is delivered, update agent stats
      if (status === 'delivered') {
        const earnings = order.amount * 0.8; // 80% of order amount goes to agent
        await supabase
          .from('agents')
          .update({ 
            total_earnings: agent.total_earnings + earnings,
            completed_deliveries: agent.completed_deliveries + 1
          })
          .eq('id', agent.id);
      }
      
      toast({
        title: 'Order Updated',
        description: `Order status updated to ${status}`,
      });
      
      if (status === 'delivered') {
        // After a short delay, redirect to completed orders page
        setTimeout(() => {
          navigate('/orders/completed');
        }, 3000);
      }
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to update order: ' + error.message,
        variant: 'destructive',
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const startQrScanner = () => {
    setIsScanning(true);
    const scannerElement = document.getElementById('qr-reader');
    
    if (!scannerElement) return;
    
    try {
      const html5QrCode = new Html5Qrcode("qr-reader");
      scannerRef.current = html5QrCode;
      
      html5QrCode.start(
        { facingMode: "environment" },
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
        },
        (decodedText) => {
          // Success callback
          console.log(`QR Code detected: ${decodedText}`);
          html5QrCode.stop();
          
          // Verify the scanned code
          if (order && decodedText === order.verification_code) {
            setIsDeliverySuccessful(true);
            // Wait a moment before closing the dialog
            setTimeout(() => {
              setIsScannerOpen(false);
              // Mark as delivered
              updateOrderStatus('delivered');
            }, 2000);
          } else {
            toast({
              title: 'Invalid QR Code',
              description: 'The scanned QR code does not match this order.',
              variant: 'destructive',
            });
          }
          setIsScanning(false);
        },
        (errorMessage) => {
          // Error callback
          console.log(`QR Code scan error: ${errorMessage}`);
        }
      )
      .then(() => {
        setIsScannerStarted(true);
      })
      .catch((err) => {
        toast({
          title: 'Scanner Error',
          description: err,
          variant: 'destructive',
        });
        setIsScanning(false);
      });
    } catch (err) {
      console.error("Error starting QR scanner:", err);
      toast({
        title: 'Scanner Error',
        description: "Failed to start QR scanner",
        variant: 'destructive',
      });
      setIsScanning(false);
    }
  };

  const stopQrScanner = () => {
    if (scannerRef.current && isScannerStarted) {
      scannerRef.current.stop()
        .then(() => {
          setIsScannerStarted(false);
          setIsScanning(false);
        })
        .catch(err => {
          console.error("Error stopping QR scanner:", err);
        });
    }
  };

  const renderOrderActions = () => {
    if (!order) return null;

    switch (order.status) {
      case 'assigned':
        return (
          <Button 
            className="w-full"
            onClick={() => updateOrderStatus('in_transit')}
            disabled={isUpdating}
          >
            {isUpdating ? (
              <>
                <Loader className="mr-2 h-4 w-4 animate-spin" />
                Updating...
              </>
            ) : (
              <>
                <Truck className="mr-2 h-4 w-4" />
                Start Delivery
              </>
            )}
          </Button>
        );
      
      case 'in_transit':
        return (
          <Button 
            className="w-full"
            onClick={() => setIsScannerOpen(true)}
            disabled={isUpdating}
          >
            <QrCode className="mr-2 h-4 w-4" />
            Scan QR to Complete Delivery
          </Button>
        );
      
      default:
        return null;
    }
  };

  const getStatusBadge = () => {
    if (!order) return null;
    
    switch(order.status) {
      case 'assigned':
        return <Badge className="bg-blue-500">Assigned</Badge>;
      case 'in_transit':
        return <Badge className="bg-amber-500">In Transit</Badge>;
      case 'delivered':
        return <Badge className="bg-success">Delivered</Badge>;
      default:
        return <Badge>{order.status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex justify-center items-center min-h-[40vh]">
          <Loader className="h-12 w-12 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!order || !agent) {
    return (
      <MainLayout>
        <div className="text-center py-10">
          <h2 className="text-2xl font-bold mb-4">Order Not Found</h2>
          <Button onClick={() => navigate('/orders/active')}>
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Orders
          </Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Back button and order header */}
        <div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => navigate('/orders/active')}
            className="mb-4"
          >
            <ChevronLeft className="mr-1 h-4 w-4" />
            Back to Orders
          </Button>
          
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                Order #{order.id.substring(0, 8)} 
                {getStatusBadge()}
              </h1>
              <p className="text-muted-foreground">
                Created {formatDistanceToNow(new Date(order.created_at), { addSuffix: true })}
              </p>
            </div>
            
            <div className="flex flex-col xs:flex-row gap-2">
              <Button variant="outline" size="sm">
                <Phone className="mr-2 h-4 w-4" />
                Call Customer
              </Button>
              <a href={`https://maps.google.com/?q=${order.delivery_location}`} target="_blank" rel="noreferrer">
                <Button variant="outline" size="sm">
                  <MapPin className="mr-2 h-4 w-4" />
                  Open in Maps
                </Button>
              </a>
            </div>
          </div>
        </div>
        
        <div className="grid gap-6 md:grid-cols-3">
          {/* Order details */}
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Order Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <h3 className="font-medium">Customer</h3>
                    <p>{order.customer_name}</p>
                    <p>{order.customer_phone}</p>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-medium">Payment</h3>
                    <p className="text-lg font-semibold">${order.amount.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">
                      Your earnings: ${(order.amount * 0.8).toFixed(2)}
                    </p>
                  </div>
                </div>
                
                <div className="space-y-4 pt-4 border-t">
                  <div className="space-y-2">
                    <div className="flex items-start">
                      <MapPin className="h-5 w-5 mr-2 text-muted-foreground flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="font-medium">Pickup Location</h3>
                        <p>{order.pickup_location}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-start">
                      <MapPin className="h-5 w-5 mr-2 text-success flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="font-medium">Delivery Location</h3>
                        <p>{order.delivery_location}</p>
                        {order.delivery_notes && (
                          <div className="mt-2 bg-muted p-2 rounded text-sm">
                            <p className="font-medium">Delivery Notes:</p>
                            <p>{order.delivery_notes}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Chat section */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="h-5 w-5 mr-2" />
                  Chat with Customer
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex flex-col">
                  <div className="flex-1 overflow-y-auto p-4 space-y-4 border rounded-md mb-4">
                    {messages.length === 0 ? (
                      <p className="text-center text-muted-foreground py-10">
                        No messages yet. Send a message to the customer.
                      </p>
                    ) : (
                      messages.map((message) => (
                        <div 
                          key={message.id}
                          className={`flex ${message.sender_type === 'agent' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div 
                            className={`max-w-[80%] p-3 rounded-lg ${
                              message.sender_type === 'agent' 
                                ? 'bg-primary text-primary-foreground' 
                                : 'bg-muted'
                            }`}
                          >
                            <p>{message.content}</p>
                            <p className="text-xs opacity-70 mt-1">
                              {formatDistanceToNow(new Date(message.created_at), { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                  
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Type your message" 
                      value={newMessage} 
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          sendMessage();
                        }
                      }}
                    />
                    <Button 
                      size="icon" 
                      onClick={sendMessage}
                      disabled={!newMessage.trim()}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Status and actions card */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Delivery Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Status</span>
                    {getStatusBadge()}
                  </div>
                  
                  <div className="w-full bg-muted rounded-full h-2.5">
                    <div 
                      className="bg-primary h-2.5 rounded-full" 
                      style={{ 
                        width: order.status === 'assigned' ? '33%' : order.status === 'in_transit' ? '66%' : '100%' 
                      }}
                    ></div>
                  </div>
                  
                  <div className="flex justify-between text-xs text-muted-foreground pt-1">
                    <span>Assigned</span>
                    <span>In Transit</span>
                    <span>Delivered</span>
                  </div>
                </div>
                
                <div className="space-y-4 pt-4 border-t">
                  {order.status === 'in_transit' && (
                    <div className="text-center p-2 bg-amber-500/10 border border-amber-500/20 rounded-md">
                      <p className="text-sm">
                        <Clock className="h-4 w-4 inline mr-1" />
                        Delivery in progress
                      </p>
                    </div>
                  )}
                  
                  {order.status === 'assigned' && (
                    <div className="text-center p-2 bg-blue-500/10 border border-blue-500/20 rounded-md">
                      <p className="text-sm">
                        <Package className="h-4 w-4 inline mr-1" />
                        Ready for pickup
                      </p>
                    </div>
                  )}
                  
                  <div className="pt-2">
                    {renderOrderActions()}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      {/* QR Code Scanner Dialog */}
      <Dialog open={isScannerOpen} onOpenChange={(open) => {
        setIsScannerOpen(open);
        if (!open && isScannerStarted) {
          stopQrScanner();
        }
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Scan Delivery Confirmation QR Code</DialogTitle>
            <DialogDescription>
              Ask the customer to show you their QR code to confirm delivery.
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex flex-col items-center justify-center gap-4">
            {isDeliverySuccessful ? (
              <div className="text-center py-4">
                <CheckCircle className="h-16 w-16 text-success mx-auto" />
                <h3 className="text-xl font-medium mt-4">Delivery Verified!</h3>
                <p className="text-muted-foreground mt-1">
                  Marking order as delivered...
                </p>
              </div>
            ) : (
              <>
                <div id="qr-reader" className="w-full max-w-[300px] h-[300px] bg-muted/50"></div>
                
                <div className="flex gap-2 justify-center w-full">
                  {!isScanning && (
                    <Button onClick={startQrScanner} className="w-full">
                      Start Scanner
                    </Button>
                  )}
                  
                  {isScanning && (
                    <Button variant="outline" onClick={stopQrScanner} className="w-full">
                      Cancel
                    </Button>
                  )}
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default OrderDetailPage;
