
import React from 'react';
import MainLayout from '@/components/layouts/MainLayout';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { TrendingUp, TrendingDown, CheckCircle, XCircle, Target } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Skeleton } from '@/components/ui/skeleton';

// This type represents our agent stats
type AgentStats = {
  successful_deliveries: number;
  unsuccessful_deliveries: number;
  total_deliveries: number;
  earnings: number;
  agent_id: string;
}

// This function fetches agent stats
const fetchAgentStats = async (agentId: string): Promise<AgentStats> => {
  try {
    // Fetch successful deliveries
    const { data: successfulDeliveries, error: successError } = await supabase
      .from('orders')
      .select('count')
      .eq('agent_id', agentId)
      .eq('status', 'delivered');
    
    if (successError) throw successError;
    
    // Fetch unsuccessful deliveries (cancelled after assignment)
    const { data: unsuccessfulDeliveries, error: unsuccessError } = await supabase
      .from('orders')
      .select('count')
      .eq('agent_id', agentId)
      .eq('status', 'cancelled');
    
    if (unsuccessError) throw unsuccessError;
    
    // Fetch earnings
    const { data: agentData, error: agentError } = await supabase
      .from('agents')
      .select('total_earnings')
      .eq('id', agentId)
      .single();
    
    if (agentError) throw agentError;
    
    return {
      successful_deliveries: successfulDeliveries[0]?.count || 0,
      unsuccessful_deliveries: unsuccessfulDeliveries[0]?.count || 0,
      total_deliveries: (successfulDeliveries[0]?.count || 0) + (unsuccessfulDeliveries[0]?.count || 0),
      earnings: agentData?.total_earnings || 0,
      agent_id: agentId
    };
  } catch (error) {
    console.error("Error fetching agent stats:", error);
    // Return default values in case of error
    return {
      successful_deliveries: 0,
      unsuccessful_deliveries: 0,
      total_deliveries: 0,
      earnings: 0,
      agent_id: agentId
    };
  }
};

// Sample data for future targets (in a real app, this might come from the backend)
const futureTargets = [
  { name: 'Week 1', target: 10, actual: 8 },
  { name: 'Week 2', target: 12, actual: 10 },
  { name: 'Week 3', target: 15, actual: 12 },
  { name: 'Week 4', target: 18, actual: 15 },
];

// Sample monthly data (in a real app, this would be fetched from the backend)
const monthlyDeliveries = [
  { month: 'Jan', deliveries: 5 },
  { month: 'Feb', deliveries: 8 },
  { month: 'Mar', deliveries: 12 },
  { month: 'Apr', deliveries: 10 },
  { month: 'May', deliveries: 15 },
  { month: 'Jun', deliveries: 18 },
];

const AnalyticsPage = () => {
  const { user } = useAuth();

  // Fetch current agent ID using the user's ID
  const { data: agent, isLoading: isLoadingAgent } = useQuery({
    queryKey: ['agent', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('agents')
        .select('id')
        .eq('user_id', user?.id)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Fetch agent stats once we have the agent ID
  const { data: agentStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['agentStats', agent?.id],
    queryFn: () => fetchAgentStats(agent?.id as string),
    enabled: !!agent?.id,
  });

  const isLoading = isLoadingAgent || isLoadingStats;

  const COLORS = ['#0088FE', '#FF8042'];

  const pieData = [
    { name: 'Successful', value: agentStats?.successful_deliveries || 0 },
    { name: 'Unsuccessful', value: agentStats?.unsuccessful_deliveries || 0 },
  ];

  return (
    <MainLayout>
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-6">Analytics</h1>
        
        {/* Top Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {/* Successful Deliveries Card */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Successful Deliveries
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                {isLoading ? (
                  <Skeleton className="h-9 w-20" />
                ) : (
                  <div className="text-3xl font-bold">
                    {agentStats?.successful_deliveries || 0}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          {/* Unsuccessful Deliveries Card */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Unsuccessful Deliveries
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <XCircle className="h-5 w-5 text-red-500 mr-2" />
                {isLoading ? (
                  <Skeleton className="h-9 w-20" />
                ) : (
                  <div className="text-3xl font-bold">
                    {agentStats?.unsuccessful_deliveries || 0}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          {/* Total Deliveries Card */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Deliveries
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                {isLoading ? (
                  <Skeleton className="h-9 w-20" />
                ) : (
                  <div className="text-3xl font-bold">
                    {agentStats?.total_deliveries || 0}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          {/* Total Earnings Card */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Earnings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                {isLoading ? (
                  <Skeleton className="h-9 w-20" />
                ) : (
                  <div className="text-3xl font-bold">
                    ${agentStats?.earnings.toFixed(2) || '0.00'}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Delivery Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Delivery Performance</CardTitle>
              <CardDescription>Successful vs. Unsuccessful Deliveries</CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              {isLoading ? (
                <div className="h-full w-full flex items-center justify-center">
                  <Skeleton className="h-64 w-full" />
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Legend />
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
          
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Monthly Deliveries</CardTitle>
              <CardDescription>Number of deliveries per month</CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyDeliveries}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="deliveries" fill="#8884d8" name="Deliveries" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
        
        {/* Future Targets */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Future Targets</CardTitle>
              <CardDescription>Your delivery targets vs. actual performance</CardDescription>
            </div>
            <Target className="h-6 w-6 text-primary" />
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={futureTargets}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="target"
                  stroke="#8884d8"
                  activeDot={{ r: 8 }}
                  name="Target"
                />
                <Line type="monotone" dataKey="actual" stroke="#82ca9d" name="Actual" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
          <CardFooter className="bg-muted/50 border-t">
            <div className="flex flex-col gap-1 text-sm">
              <div className="flex items-center">
                <TrendingUp className="h-4 w-4 mr-1 text-green-500" />
                <span>You're on track to meet your monthly targets!</span>
              </div>
              <div className="flex items-center text-muted-foreground">
                <span>Keep up the good work to earn performance bonuses.</span>
              </div>
            </div>
          </CardFooter>
        </Card>
      </div>
    </MainLayout>
  );
};

export default AnalyticsPage;
