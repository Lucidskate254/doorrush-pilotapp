
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  PackageCheck, 
  DollarSign, 
  Clock, 
  MapPin,
  ArrowUpRight,
  Loader,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Agent, Activity } from '@/types';
import { formatDistanceToNow } from 'date-fns';

import MainLayout from '@/components/layouts/MainLayout';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

const DashboardPage = () => {
  const [agent, setAgent] = useState<Agent | null>(null);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAgentData = async () => {
      if (!user) return;
      
      try {
        // Fetch agent data
        const { data: agentData, error: agentError } = await supabase
          .from('agents')
          .select('*')
          .eq('user_id', user.id)
          .single();
        
        if (agentError) throw agentError;
        
        if (agentData) {
          setAgent(agentData);
          setIsOnline(agentData.status === 'online');
          
          // Fetch recent activities
          const { data: activityData, error: activityError } = await supabase
            .from('activities')
            .select('*')
            .eq('agent_id', agentData.id)
            .order('created_at', { ascending: false })
            .limit(5);
          
          if (activityError) throw activityError;
          setActivities(activityData || []);
        } else {
          // If agent profile doesn't exist, redirect to registration
          navigate('/agent-registration');
        }
      } catch (error: any) {
        toast({
          title: 'Error',
          description: 'Failed to load agent data: ' + error.message,
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchAgentData();
  }, [user, navigate, toast]);

  const toggleOnlineStatus = async () => {
    if (!agent) return;
    
    const newStatus = !isOnline ? 'online' : 'offline';
    setIsUpdating(true);
    
    try {
      // Update agent status in database
      const { error: updateError } = await supabase
        .from('agents')
        .update({ status: newStatus })
        .eq('id', agent.id);
      
      if (updateError) throw updateError;
      
      // Create activity record
      await supabase
        .from('activities')
        .insert({
          agent_id: agent.id,
          activity_type: 'status_change',
          description: `Agent status changed to ${newStatus}`,
        });
      
      setIsOnline(!isOnline);
      
      toast({
        title: 'Status Updated',
        description: `You are now ${newStatus}`,
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to update status: ' + error.message,
        variant: 'destructive',
      });
    } finally {
      setIsUpdating(false);
    }
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex justify-center items-center min-h-[60vh]">
          <Loader className="h-12 w-12 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!agent) {
    return (
      <MainLayout>
        <div className="text-center py-10">
          <h2 className="text-2xl font-bold mb-4">Agent Profile Not Found</h2>
          <p className="mb-6">Please complete your agent registration first.</p>
          <Button onClick={() => navigate('/agent-registration')}>
            Register as Agent
          </Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header with agent info */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Welcome, {agent.full_name}</h1>
            <p className="text-muted-foreground">Your dashboard overview and summary</p>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center gap-4">
            <div className="flex items-center space-x-2">
              <Switch 
                checked={isOnline} 
                onCheckedChange={toggleOnlineStatus}
                disabled={isUpdating}
              />
              <Label 
                className={isOnline ? "text-success" : "text-muted-foreground"}
              >
                {isOnline ? 'Online' : 'Offline'}
              </Label>
            </div>
            
            <div className="flex items-center p-2 bg-muted rounded-md">
              <MapPin className="h-4 w-4 mr-1 text-muted-foreground" />
              <span className="text-sm">{agent.service_area}</span>
            </div>
            
            <div className="flex items-center p-2 bg-muted rounded-md">
              <span className="text-sm font-medium">Agent ID: {agent.agent_code}</span>
            </div>
          </div>
        </div>
        
        {/* Stats cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${agent.total_earnings.toFixed(2)}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed Deliveries</CardTitle>
              <PackageCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{agent.completed_deliveries}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0</div> {/* This would be fetched from orders */}
            </CardContent>
          </Card>
        </div>
        
        {/* Actions */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Available Orders</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <p>View orders available for pickup in your service area.</p>
            </CardContent>
            <CardFooter>
              <Button onClick={() => navigate('/orders/available')} className="w-full">
                Browse Orders
                <ArrowUpRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Your Active Deliveries</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <p>Manage and track your current assigned deliveries.</p>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={() => navigate('/orders/active')} 
                variant="outline"
                className="w-full"
              >
                View Active Deliveries
                <ArrowUpRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        {/* Recent activity */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
          <div className="space-y-2">
            {activities.length > 0 ? (
              activities.map((activity) => (
                <div 
                  key={activity.id} 
                  className="flex items-center p-3 border rounded-lg"
                >
                  <div className="mr-4 bg-primary/10 p-2 rounded-full">
                    {activity.activity_type === 'login' && (
                      <Clock className="h-4 w-4 text-primary" />
                    )}
                    {activity.activity_type === 'status_change' && (
                      <Clock className="h-4 w-4 text-info" />
                    )}
                    {activity.activity_type === 'order_accepted' && (
                      <PackageCheck className="h-4 w-4 text-warning" />
                    )}
                    {activity.activity_type === 'order_completed' && (
                      <PackageCheck className="h-4 w-4 text-success" />
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <p className="text-sm">{activity.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(activity.created_at), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground text-center py-6">No recent activity</p>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default DashboardPage;
