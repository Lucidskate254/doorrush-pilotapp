
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Loader, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import AuthLayout from '@/components/layouts/AuthLayout';

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

const registrationSchema = z.object({
  fullName: z.string().min(3, { message: 'Full name must be at least 3 characters' }),
  phoneNumber: z.string().min(10, { message: 'Please enter a valid phone number' }),
  nationalId: z.string().min(5, { message: 'National ID is required' }),
  serviceArea: z.string().min(2, { message: 'Service area is required' }),
});

type RegistrationFormValues = z.infer<typeof registrationSchema>;

const AgentRegistrationPage = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  // Generate a random agent code
  const generateAgentCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  const form = useForm<RegistrationFormValues>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      fullName: '',
      phoneNumber: '',
      nationalId: '',
      serviceArea: '',
    },
  });

  useEffect(() => {
    // Get data from sessionStorage
    const fullName = sessionStorage.getItem('fullName') || '';
    const phoneNumber = sessionStorage.getItem('phoneNumber') || '';
    
    // Pre-fill the form if data exists
    if (fullName) form.setValue('fullName', fullName);
    if (phoneNumber) form.setValue('phoneNumber', phoneNumber);
  }, [form]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setProfileImage(file);
      
      // Create a preview
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: RegistrationFormValues) => {
    if (!user) {
      toast({
        title: 'Authentication Error',
        description: 'You must be logged in to register as an agent',
        variant: 'destructive',
      });
      return;
    }

    if (!profileImage) {
      toast({
        title: 'Missing Profile Picture',
        description: 'Please upload a profile picture',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Upload profile picture to Supabase Storage
      const fileExt = profileImage.name.split('.').pop();
      const fileName = `${user.id}-${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
      const filePath = `agent-profiles/${fileName}`;

      const { error: uploadError, data: uploadData } = await supabase.storage
        .from('agent-profiles')
        .upload(filePath, profileImage);

      if (uploadError) {
        throw new Error('Error uploading profile picture: ' + uploadError.message);
      }

      // 2. Get the public URL for the uploaded image
      const { data: { publicUrl } } = supabase.storage
        .from('agent-profiles')
        .getPublicUrl(filePath);

      // 3. Generate unique agent code
      const agentCode = generateAgentCode();

      // 4. Insert agent record in Supabase
      const { error: insertError } = await supabase
        .from('agents')
        .insert({
          user_id: user.id,
          full_name: data.fullName,
          email: user.email || '',
          phone_number: data.phoneNumber,
          national_id: data.nationalId,
          service_area: data.serviceArea,
          profile_picture_url: publicUrl,
          agent_code: agentCode,
          status: 'offline',
          total_earnings: 0,
          completed_deliveries: 0,
        });

      if (insertError) {
        throw new Error('Error creating agent profile: ' + insertError.message);
      }

      // Clear sessionStorage
      sessionStorage.removeItem('fullName');
      sessionStorage.removeItem('phoneNumber');
      sessionStorage.removeItem('email');

      // Show success message
      toast({
        title: 'Registration Successful',
        description: 'Your agent account has been created.',
      });

      // Redirect to dashboard
      navigate('/dashboard');

    } catch (error: any) {
      toast({
        title: 'Registration Failed',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AuthLayout 
      title="Complete Your Agent Profile" 
      description="Provide your details to start receiving delivery orders"
    >
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="fullName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Full Name</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="phoneNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Phone Number</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="nationalId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>National ID</FormLabel>
                <FormControl>
                  <Input placeholder="Your identification number" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="serviceArea"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Service Area</FormLabel>
                <FormControl>
                  <Input placeholder="City or area you'll operate in" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="space-y-2">
            <FormLabel>Profile Picture</FormLabel>
            <Card className="p-4 flex flex-col items-center justify-center space-y-4">
              {imagePreview ? (
                <div className="relative w-32 h-32">
                  <img 
                    src={imagePreview} 
                    alt="Profile preview" 
                    className="w-full h-full object-cover rounded-full"
                  />
                  <Button 
                    type="button"
                    variant="secondary"
                    size="sm"
                    className="absolute bottom-0 right-0"
                    onClick={() => {
                      setProfileImage(null);
                      setImagePreview(null);
                    }}
                  >
                    Change
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col items-center space-y-2">
                  <div className="bg-gray-100 rounded-full p-4">
                    <Upload className="h-8 w-8 text-gray-500" />
                  </div>
                  <label htmlFor="profile-image" className="cursor-pointer">
                    <span className="text-sm font-medium text-primary hover:text-primary-700">
                      Upload a photo
                    </span>
                    <input
                      id="profile-image"
                      name="profile-image"
                      type="file"
                      className="sr-only"
                      onChange={handleImageChange}
                      accept="image/*"
                    />
                  </label>
                  <p className="text-xs text-gray-500">
                    PNG, JPG, GIF up to 10MB
                  </p>
                </div>
              )}
            </Card>
          </div>
          
          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader className="mr-2 h-4 w-4 animate-spin" />
                Creating your profile...
              </>
            ) : (
              'Complete Registration'
            )}
          </Button>
        </form>
      </Form>
    </AuthLayout>
  );
};

export default AgentRegistrationPage;
