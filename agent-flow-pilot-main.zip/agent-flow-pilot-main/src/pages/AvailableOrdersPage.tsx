
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  MapPin, 
  Clock, 
  DollarSign, 
  Loader,
  PackageOpen,
  User
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Order, Agent } from '@/types';
import MainLayout from '@/components/layouts/MainLayout';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';

const AvailableOrdersPage = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAccepting, setIsAccepting] = useState(false);
  const [agent, setAgent] = useState<Agent | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        // First fetch the agent data to get service area
        const { data: agentData, error: agentError } = await supabase
          .from('agents')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (agentError) throw agentError;
        setAgent(agentData);

        // Then fetch available orders in the agent's service area
        const { data: ordersData, error: ordersError } = await supabase
          .from('orders')
          .select('*')
          .eq('status', 'pending')
          .eq('pickup_location', agentData.service_area) // Filter by agent's service area
          .order('created_at', { ascending: false });

        if (ordersError) throw ordersError;
        setOrders(ordersData || []);
      } catch (error: any) {
        toast({
          title: 'Error',
          description: 'Failed to load available orders: ' + error.message,
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [user, toast]);

  const acceptOrder = async (orderId: string) => {
    if (!agent || !user) return;
    
    setIsAccepting(true);
    
    try {
      // Update order status to assigned
      const { error: updateError } = await supabase
        .from('orders')
        .update({ 
          status: 'assigned',
          agent_id: agent.id
        })
        .eq('id', orderId);
      
      if (updateError) throw updateError;
      
      // Create activity record
      await supabase
        .from('activities')
        .insert({
          agent_id: agent.id,
          activity_type: 'order_accepted',
          description: `Order #${orderId.substring(0, 8)} accepted`,
        });
      
      toast({
        title: 'Order Accepted',
        description: 'You have successfully accepted this order.',
      });
      
      // Redirect to order details
      navigate(`/orders/${orderId}`);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to accept order: ' + error.message,
        variant: 'destructive',
      });
    } finally {
      setIsAccepting(false);
    }
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Available Orders</h1>
          <p className="text-muted-foreground">
            Browse and accept delivery orders in your area
          </p>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center min-h-[40vh]">
            <Loader className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : orders.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {orders.map((order) => (
              <Card key={order.id} className="overflow-hidden">
                <div className="bg-primary/10 p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      <PackageOpen className="h-5 w-5 text-primary mr-2" />
                      <span className="font-medium">
                        Order #{order.id.substring(0, 8)}
                      </span>
                    </div>
                    <div className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
                      ${order.amount.toFixed(2)}
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-4 space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <User className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{order.customer_name}</span>
                    </div>
                    
                    <div className="flex items-start text-sm">
                      <MapPin className="h-4 w-4 mr-2 text-muted-foreground flex-shrink-0 mt-1" />
                      <div>
                        <div className="font-medium">Pickup</div>
                        <div>{order.pickup_location}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start text-sm">
                      <MapPin className="h-4 w-4 mr-2 text-success flex-shrink-0 mt-1" />
                      <div>
                        <div className="font-medium">Delivery</div>
                        <div>{order.delivery_location}</div>
                      </div>
                    </div>
                    
                    {order.delivery_notes && (
                      <div className="bg-muted p-2 rounded text-sm">
                        <p className="font-medium">Notes:</p>
                        <p>{order.delivery_notes}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex justify-between items-center text-xs text-muted-foreground">
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatDistanceToNow(new Date(order.created_at), { addSuffix: true })}
                    </div>
                    
                    <div className="flex items-center">
                      <DollarSign className="h-3 w-3 mr-1" />
                      Earnings: ${(order.amount * 0.8).toFixed(2)}
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="p-4 pt-0">
                  <Button 
                    className="w-full"
                    onClick={() => acceptOrder(order.id)}
                    disabled={isAccepting}
                  >
                    {isAccepting ? (
                      <>
                        <Loader className="mr-2 h-4 w-4 animate-spin" />
                        Accepting...
                      </>
                    ) : (
                      'Accept Order'
                    )}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-muted/30 rounded-lg">
            <PackageOpen className="mx-auto h-12 w-12 text-muted-foreground/50" />
            <h3 className="mt-4 text-lg font-medium">No Available Orders</h3>
            <p className="mt-2 text-muted-foreground">
              There are currently no orders available in your service area.
              <br />
              Check back later or update your service area in settings.
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default AvailableOrdersPage;
