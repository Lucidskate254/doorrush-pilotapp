import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  MapPin, 
  Clock, 
  Loader,
  PackageOpen,
  User,
  ArrowRight
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Order, Agent } from '@/types';
import MainLayout from '@/components/layouts/MainLayout';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const ActiveOrdersPage = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [agent, setAgent] = useState<Agent | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  
  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        // First fetch the agent data
        const { data: agentData, error: agentError } = await supabase
          .from('agents')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (agentError) throw agentError;
        setAgent(agentData);

        // Then fetch active orders for this agent
        const { data: ordersData, error: ordersError } = await supabase
          .from('orders')
          .select('*')
          .eq('agent_id', agentData.id)
          .in('status', ['assigned', 'in_transit'])
          .order('created_at', { ascending: false });

        if (ordersError) throw ordersError;
        setOrders(ordersData || []);

        // Set up real-time subscription for orders
        const subscription = supabase
          .channel('orders-channel')
          .on('postgres_changes', 
            { 
              event: '*', 
              schema: 'public', 
              table: 'orders',
              filter: `agent_id=eq.${agentData.id}`
            }, 
            (payload) => {
              console.log('Orders change received:', payload);
              if (payload.eventType === 'UPDATE') {
                // Update the order in the state
                setOrders(prevOrders => {
                  const updatedOrder = payload.new as Order;
                  // If the order is no longer active (delivered/cancelled), remove it
                  if (updatedOrder.status === 'delivered' || updatedOrder.status === 'cancelled') {
                    return prevOrders.filter(o => o.id !== updatedOrder.id);
                  }
                  // Otherwise update it
                  return prevOrders.map(o => o.id === updatedOrder.id ? updatedOrder : o);
                });
              }
            })
          .subscribe();
        
        // Clean up subscription on unmount
        return () => {
          subscription.unsubscribe();
        };

      } catch (error: any) {
        toast({
          title: 'Error',
          description: 'Failed to load active orders: ' + error.message,
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [user, toast]);

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'assigned':
        return <Badge className="bg-blue-500">Assigned</Badge>;
      case 'in_transit':
        return <Badge className="bg-amber-500">In Transit</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Active Orders</h1>
          <p className="text-muted-foreground">
            Manage your current deliveries
          </p>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center min-h-[40vh]">
            <Loader className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : orders.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {orders.map((order) => (
              <Card key={order.id} className="overflow-hidden">
                <div className="bg-primary/10 p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      <PackageOpen className="h-5 w-5 text-primary mr-2" />
                      <span className="font-medium">
                        Order #{order.id.substring(0, 8)}
                      </span>
                    </div>
                    {getStatusBadge(order.status)}
                  </div>
                </div>
                
                <CardContent className="p-4 space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <User className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{order.customer_name}</span>
                    </div>
                    
                    <div className="flex items-start text-sm">
                      <MapPin className="h-4 w-4 mr-2 text-muted-foreground flex-shrink-0 mt-1" />
                      <div>
                        <div className="font-medium">Pickup</div>
                        <div>{order.pickup_location}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start text-sm">
                      <MapPin className="h-4 w-4 mr-2 text-success flex-shrink-0 mt-1" />
                      <div>
                        <div className="font-medium">Delivery</div>
                        <div>{order.delivery_location}</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Clock className="h-3 w-3 mr-1" />
                    Amount: ${order.amount.toFixed(2)}
                  </div>
                </CardContent>
                
                <CardFooter className="p-4 pt-0">
                  <Link to={`/orders/${order.id}`} className="w-full">
                    <Button 
                      variant="default"
                      className="w-full"
                    >
                      Manage Order
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-muted/30 rounded-lg">
            <PackageOpen className="mx-auto h-12 w-12 text-muted-foreground/50" />
            <h3 className="mt-4 text-lg font-medium">No Active Orders</h3>
            <p className="mt-2 text-muted-foreground">
              You don't have any active orders right now.
              <br />
              Browse available orders to find delivery opportunities.
            </p>
            <Link to="/orders/available">
              <Button className="mt-4">
                Browse Available Orders
              </Button>
            </Link>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default ActiveOrdersPage;
