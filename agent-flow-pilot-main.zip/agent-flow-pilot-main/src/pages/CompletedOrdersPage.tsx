
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  MapPin, 
  Clock, 
  Loader,
  CheckCircle,
  User,
  Search,
  Calendar
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Order, Agent } from '@/types';
import MainLayout from '@/components/layouts/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { format } from 'date-fns';

const CompletedOrdersPage = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [agent, setAgent] = useState<Agent | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  
  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        // First fetch the agent data
        const { data: agentData, error: agentError } = await supabase
          .from('agents')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (agentError) throw agentError;
        setAgent(agentData);

        // Then fetch completed orders for this agent
        const { data: ordersData, error: ordersError } = await supabase
          .from('orders')
          .select('*')
          .eq('agent_id', agentData.id)
          .eq('status', 'delivered')
          .order('created_at', { ascending: false });

        if (ordersError) throw ordersError;
        setOrders(ordersData || []);
      } catch (error: any) {
        toast({
          title: 'Error',
          description: 'Failed to load completed orders: ' + error.message,
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [user, toast]);

  // Filter orders based on search query
  const filteredOrders = orders.filter(order =>
    order.customer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    order.delivery_location.toLowerCase().includes(searchQuery.toLowerCase()) ||
    order.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Completed Orders</h1>
          <p className="text-muted-foreground">
            View your order delivery history
          </p>
        </div>
        
        {/* Search input */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            className="pl-10"
            placeholder="Search by customer name, location or order ID"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center min-h-[40vh]">
            <Loader className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : filteredOrders.length > 0 ? (
          <div className="space-y-4">
            {filteredOrders.map((order) => (
              <Card key={order.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div className="bg-success/10 p-2 rounded-full">
                        <CheckCircle className="h-8 w-8 text-success" />
                      </div>
                      
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium">Order #{order.id.substring(0, 8)}</h3>
                          <Badge className="bg-success">Delivered</Badge>
                        </div>
                        
                        <div className="flex flex-col gap-1 text-sm">
                          <div className="flex items-center">
                            <User className="h-3 w-3 mr-1 text-muted-foreground" />
                            <span>{order.customer_name}</span>
                          </div>
                          
                          <div className="flex items-center">
                            <MapPin className="h-3 w-3 mr-1 text-muted-foreground" />
                            <span>{order.delivery_location}</span>
                          </div>
                          
                          <div className="flex items-center">
                            <Calendar className="h-3 w-3 mr-1 text-muted-foreground" />
                            <span>
                              {format(new Date(order.updated_at), 'MMM dd, yyyy')} at{' '}
                              {format(new Date(order.updated_at), 'hh:mm a')}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col md:items-end gap-1">
                      <div className="text-lg font-semibold">${order.amount.toFixed(2)}</div>
                      <div className="text-sm text-success">
                        Earned ${(order.amount * 0.8).toFixed(2)}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-muted/30 rounded-lg">
            <CheckCircle className="mx-auto h-12 w-12 text-muted-foreground/50" />
            <h3 className="mt-4 text-lg font-medium">No Completed Orders</h3>
            <p className="mt-2 text-muted-foreground">
              You haven't completed any deliveries yet.
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default CompletedOrdersPage;
