
import { useEffect } from 'react';
import { Navigate } from 'react-router-dom';

const Index = () => {
  useEffect(() => {
    document.title = "Agent Flow | Delivery Management Platform";
  }, []);

  // Just redirect to home
  return <Navigate to="/" replace />;
};

export default Index;
