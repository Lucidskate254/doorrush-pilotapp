
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, Package, Shield, Award, TrendingUp } from 'lucide-react';

const LandingPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header / Navigation */}
      <header className="px-4 lg:px-8 h-16 flex items-center">
        <div className="container flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Package className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl">Agent Flow</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link to="/signin">
              <Button variant="ghost">Sign in</Button>
            </Link>
            <Link to="/signup">
              <Button>Join as Agent</Button>
            </Link>
          </div>
        </div>
      </header>
      
      {/* Hero section */}
      <section className="py-20 px-4 lg:py-32">
        <div className="container flex flex-col items-center text-center">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
            Deliver More.<br />
            <span className="text-primary">Earn More</span>.
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
            Join our network of trusted delivery agents and start earning money on your own schedule.
            Connect with customers, track deliveries, and grow your income.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4">
            <Link to="/signup">
              <Button size="lg" className="w-full sm:w-auto">
                Get Started
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="w-full sm:w-auto">
              Learn More
            </Button>
          </div>
        </div>
      </section>
      
      {/* Features section */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container">
          <h2 className="text-3xl font-bold tracking-tight text-center">
            Why Join Agent Flow?
          </h2>
          <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="flex flex-col items-center text-center">
              <div className="rounded-full bg-primary/10 p-4 mb-4">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Flexible Earnings</h3>
              <p className="mt-2 text-muted-foreground">
                Choose your own hours and deliver when it suits your schedule. No minimum hours required.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="rounded-full bg-primary/10 p-4 mb-4">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Secure Platform</h3>
              <p className="mt-2 text-muted-foreground">
                Our platform ensures secure transactions and verified customer interactions for your safety.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="rounded-full bg-primary/10 p-4 mb-4">
                <Award className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Growth Opportunities</h3>
              <p className="mt-2 text-muted-foreground">
                Top-performing agents get priority access to high-value deliveries and bonuses.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA section */}
      <section className="py-16 px-4 lg:py-24">
        <div className="container">
          <div className="rounded-xl bg-primary p-8 md:p-10 lg:p-16 text-center">
            <h2 className="text-3xl font-bold tracking-tight text-primary-foreground">
              Ready to start delivering?
            </h2>
            <p className="mt-4 text-lg text-primary-foreground/80 max-w-2xl mx-auto">
              Join thousands of agents already using our platform to earn extra income
              and be their own boss.
            </p>
            <Link to="/signup" className="mt-8 inline-block">
              <Button size="lg" variant="secondary">
                Sign up now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-muted py-8 px-4 mt-auto">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <Package className="h-6 w-6 text-primary mr-2" />
              <span className="font-semibold">Agent Flow</span>
            </div>
            <div className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Agent Flow. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
