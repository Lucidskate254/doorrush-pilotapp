
import React, { useState, useEffect } from 'react';
import { useTheme } from 'next-themes';
import MainLayout from '@/components/layouts/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Bell, Moon, Sun, Volume2, VolumeX } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useLocalStorage } from '@/hooks/useLocalStorage';

const SettingsPage = () => {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [toastNotifications, setToastNotifications] = useLocalStorage('toastNotifications', true);
  const [inAppNotifications, setInAppNotifications] = useLocalStorage('inAppNotifications', true);
  
  // Prevent hydration mismatch by only rendering after mount
  useEffect(() => {
    setMounted(true);
  }, []);

  const handleDarkModeToggle = (checked: boolean) => {
    setTheme(checked ? 'dark' : 'light');
    toast({
      title: `${checked ? 'Dark' : 'Light'} mode activated`,
      description: `You've switched to ${checked ? 'dark' : 'light'} mode.`,
    });
  };

  const handleToastNotificationsToggle = (checked: boolean) => {
    setToastNotifications(checked);
    if (checked) {
      toast({
        title: 'Toast notifications enabled',
        description: 'You will now receive toast notifications.',
      });
    }
  };

  const handleInAppNotificationsToggle = (checked: boolean) => {
    setInAppNotifications(checked);
    if (toastNotifications) {
      toast({
        title: 'In-app notifications ' + (checked ? 'enabled' : 'disabled'),
        description: `You will ${checked ? 'now' : 'no longer'} receive in-app notifications.`,
      });
    }
  };

  // Don't render until after client-side hydration
  if (!mounted) return null;

  return (
    <MainLayout>
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-6">Settings</h1>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Notifications
            </CardTitle>
            <CardDescription>Configure how you want to receive notifications</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {toastNotifications ? (
                  <Volume2 className="h-5 w-5 text-muted-foreground" />
                ) : (
                  <VolumeX className="h-5 w-5 text-muted-foreground" />
                )}
                <Label htmlFor="toast-notifications">Toast notifications</Label>
              </div>
              <Switch
                id="toast-notifications"
                checked={toastNotifications}
                onCheckedChange={handleToastNotificationsToggle}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Bell className="h-5 w-5 text-muted-foreground" />
                <Label htmlFor="in-app-notifications">In-app notifications</Label>
              </div>
              <Switch
                id="in-app-notifications"
                checked={inAppNotifications}
                onCheckedChange={handleInAppNotificationsToggle}
              />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {theme === 'dark' ? (
                <Moon className="h-5 w-5" />
              ) : (
                <Sun className="h-5 w-5" />
              )}
              Appearance
            </CardTitle>
            <CardDescription>Customize how the application looks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {theme === 'dark' ? (
                  <Moon className="h-5 w-5 text-muted-foreground" />
                ) : (
                  <Sun className="h-5 w-5 text-muted-foreground" />
                )}
                <Label htmlFor="dark-mode">Dark mode</Label>
              </div>
              <Switch
                id="dark-mode"
                checked={theme === 'dark'}
                onCheckedChange={handleDarkModeToggle}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
};

export default SettingsPage;
